package com.example.tokyotour.Administrator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.tokyotour.Login;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.R;

import java.io.File;

public class AdminPanel extends AppCompatActivity {

    EditText name,address,summary,description,price;
    Button addPhoto,addPlace;
    Toolbar toolbar;
    String currImageURI;
    ImageView myImage;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferenceEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        name = findViewById(R.id.admin_name);
        address = findViewById(R.id.admin_address);
        summary = findViewById(R.id.admin_summary);
        description = findViewById(R.id.admin_description);
        price = findViewById(R.id.admin_price);
        addPhoto = findViewById(R.id.admin_photo);
        myImage = findViewById(R.id.imageviewTest);
        addPlace = findViewById(R.id.admin_add_place);
        toolbar = findViewById(R.id.admin_toolbar);

        currImageURI = "";

        setSupportActionBar(toolbar);
        toolbar.setTitle("Tokyo Tour");
        toolbar.setTitleTextColor(getResources().getColor(R.color.colorPrimary));

        addPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                startActivityForResult(intent,1);
            }
        });

        addPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    TouristPlace touristPlace = new TouristPlace(name.getText().toString(),address.getText().toString(),summary.getText().toString(),description.getText().toString(),currImageURI,Double.valueOf(price.getText().toString()));

                    Login.connection.getAdminDao().addTouristPlace(touristPlace);

                    AlertDialog.Builder popUpBox = new AlertDialog.Builder(AdminPanel.this);

                    //Setting configuration for the pop up box
                    popUpBox.setTitle("Done");
                    popUpBox.setMessage("Placed successfully added.");
                    popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            name.getText().clear();
                            address.getText().clear();
                            summary.getText().clear();
                            description.getText().clear();
                            price.getText().clear();
                            currImageURI = "";
                            name.requestFocus();
                        }
                    });
                    popUpBox.show();
                } else{ //Some field is left blank
                    AlertDialog.Builder popUpBox = new AlertDialog.Builder(AdminPanel.this);

                    //Setting configuration for the pop up box
                    popUpBox.setTitle("Error!");
                    popUpBox.setMessage("All fields are required!");
                    popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    popUpBox.show();
                }
            }
        });
    }

    public boolean validate(){
        if(!name.getText().toString().equals("") && !address.getText().toString().equals("") && !summary.getText().toString().equals("")
        && !description.getText().toString().equals("") && !price.getText().toString().equals("") && !currImageURI.equals("")){
            return true;
        } else{
            return false;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                Log.d("path", String.valueOf(data.getData()));
                currImageURI = String.valueOf(data.getData());
                Uri uri = Uri.parse(currImageURI);
                myImage.setImageURI(uri);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if(itemId == R.id.admin_logout){
            sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
            preferenceEditor = sharedPreferences.edit();

            preferenceEditor.remove("username");
            preferenceEditor.remove("password");
            preferenceEditor.remove("isAdmin");
            preferenceEditor.apply();

            Intent intent = new Intent(AdminPanel.this,Login.class);
            startActivity(intent);
            finish();
        }

        return true;
    }
}
