package com.example.tokyotour;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.tokyotour.ModelClasses.Rating;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.ModelClasses.User;
import com.example.tokyotour.ModelClasses.WishList;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void addUser(User user);

    @Query("SELECT * from user")
    List<User> getAllUsers();

    @Query("SELECT * from touristplace")
    List<TouristPlace> getAllTouristPlaces();

    @Query("SELECT count(wishListId) from wishlist where username like :username and id = :id and isAvailable = 1")
    int isPlaceInWishlist(String username, int id);

    @Insert
    void addPlaceToWishList(WishList wishList);

    @Query("UPDATE wishlist set isAvailable = 0 where id = :id")
    void removePlacefromWishlist(int id);

    @Query("SELECT t.* from touristplace t, wishlist w where t.id = w.id and w.username = :username and w.isAvailable = 1")
    List<TouristPlace> getPlaceForWishList(String username);

    @Query("SELECT count(ratingId) from rating where username like :username and placeId = :placeId")
    int checkIfRatingExists(String username, int placeId);

    @Insert
    void addRating(Rating rating);

    @Query("SELECT ratingNum from rating where username like :username and placeId = :placeId")
    double setRating(String username,int placeId);

    @Query("UPDATE rating set ratingNum = :ratingNum where username like :username and placeId = :placeId")
    void updateRating(String username,int placeId,double ratingNum);

    @Query("SELECT AVG(ratingNum) from rating where placeId = :placeId")
    double getAverageRating(int placeId);
}
