package com.example.tokyotour.ModelClasses;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "touristplace")
public class TouristPlace implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String address;
    private String description;
    private String detailInfo;
    private String image;
    private double price;

    public TouristPlace(String name, String address, String description, String detailInfo, String image, double price) {
        this.name = name;
        this.address = address;
        this.description = description;
        this.detailInfo = detailInfo;
        this.image = image;
        this.price = price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getDescription() {
        return description;
    }

    public String getDetailInfo() {
        return detailInfo;
    }

    public String getImage() {
        return image;
    }

    public double getPrice() {
        return price;
    }
}
