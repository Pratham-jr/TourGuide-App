package com.example.tokyotour.Tourist;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.tokyotour.Login;
import com.example.tokyotour.R;

import java.util.List;


public class TouristPlace extends Fragment {

    ListView touristPlace;
    List<com.example.tokyotour.ModelClasses.TouristPlace> touristPlaceList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tourist_place, container, false);

        touristPlace = view.findViewById(R.id.tourist_place_list);

        touristPlaceList = Login.connection.getUserDao().getAllTouristPlaces();

        TouristPlaceCustomAdapter adapter = new TouristPlaceCustomAdapter(getContext(),R.layout.tourist_place_list_item,touristPlaceList);
        touristPlace.setAdapter(adapter);

        touristPlace.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), TouristPlacePage.class);
                intent.putExtra("place",touristPlaceList.get(position));
                startActivity(intent);
            }
        });

        return view;
    }

}
