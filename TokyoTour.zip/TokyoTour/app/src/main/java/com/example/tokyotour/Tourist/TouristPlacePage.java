package com.example.tokyotour.Tourist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tokyotour.Login;
import com.example.tokyotour.MainActivity;
import com.example.tokyotour.ModelClasses.Rating;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.ModelClasses.WishList;
import com.example.tokyotour.R;
import com.like.LikeButton;
import com.like.OnLikeListener;

public class TouristPlacePage extends AppCompatActivity {

    TouristPlace touristPlace;
    ImageView photo;
    TextView price,description,name,descriptionTitle,reviewTitle,addressTitle,address;
    RatingBar ratingBar,ratingBarByUser;
    Toolbar toolbar;
    LikeButton wishlist;
    int isPlaceAlreadyInWishlist,checkIfRatingExists;
    double averageRating;
    SharedPreferences sharedPreferences;
    WishList wishList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_place_page);

        touristPlace = (TouristPlace) getIntent().getSerializableExtra("place");

        photo = findViewById(R.id.tourist_place_image);
        price = findViewById(R.id.tourist_place_price);
        description = findViewById(R.id.tourist_place_detailed_description);
        name = findViewById(R.id.tourist_place_title);
        descriptionTitle = findViewById(R.id.tourist_place_page_description_title);
        reviewTitle = findViewById(R.id.tourist_place_page_review_title);
        addressTitle = findViewById(R.id.tourist_place_page_address_title);
        address = findViewById(R.id.tourist_place_address);
        ratingBar = findViewById(R.id.tourist_place_rating);
        toolbar = findViewById(R.id.tourist_place_page_toolbar);
        ratingBarByUser = findViewById(R.id.tourist_place_rating_by_user);
        wishlist = findViewById(R.id.wishlist);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(getResources().getColor(R.color.colorPrimary));

        descriptionTitle.setPaintFlags(descriptionTitle.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        reviewTitle.setPaintFlags(descriptionTitle.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        addressTitle.setPaintFlags(descriptionTitle.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        Uri uri = Uri.parse(touristPlace.getImage());
        photo.setImageURI(uri);
        if(touristPlace.getPrice() == 0){
            price.setText("FREE");
        } else{
            price.setText("$" + touristPlace.getPrice());
        }
        description.setText(touristPlace.getDetailInfo());
        name.setText(touristPlace.getName());
        address.setText(touristPlace.getAddress());

        sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
        final String username = sharedPreferences.getString("username", "");

        //Wishlist

        //Change wishlist button to liked or unliked depending upon the data from database
        isPlaceAlreadyInWishlist = Login.connection.getUserDao().isPlaceInWishlist(username,touristPlace.getId());
        Log.d("wishlist",String.valueOf(isPlaceAlreadyInWishlist));
        Log.d("wishlist","Place id: "+touristPlace.getId());
        Log.d("wishlist",username);

        if(isPlaceAlreadyInWishlist == 0){
            wishlist.setLiked(false);
            wishlist.setEnabled(true);
        } else{
            wishlist.setLiked(true);
            wishlist.setEnabled(false);
        }

        wishlist.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                if(Login.connection.getUserDao() != null){
                    Log.d("wishlist","Not null");
                }
                Login.connection.getUserDao().addPlaceToWishList(new WishList(username,touristPlace.getId(),true));
                Log.d("wishlist","liked");
                Toast.makeText(TouristPlacePage.this,"Added to wishlist",Toast.LENGTH_LONG).show();

                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    //deprecated in API 26
                    v.vibrate(100);
                }
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                //Login.connection.getUserDao().removePlacefromWishlist(wishList.getId());
                Log.d("wishlist","unliked");
            }
        });

        //RatingBar

        checkIfRatingExists = Login.connection.getUserDao().checkIfRatingExists(username,touristPlace.getId());
        averageRating = Login.connection.getUserDao().getAverageRating(touristPlace.getId());

        ratingBar.setRating((float) averageRating);

        if(checkIfRatingExists != 0){
            ratingBarByUser.setRating((float) Login.connection.getUserDao().setRating(username,touristPlace.getId()));
        }

        ratingBarByUser.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                if(checkIfRatingExists == 0){
                    Log.d("rating","No ratings yet: "+ratingBarByUser.getRating());
                    Login.connection.getUserDao().addRating(new Rating(username,touristPlace.getId(),Double.valueOf(ratingBar.getRating())));
                    Toast.makeText(TouristPlacePage.this,"Thank you for your rating",Toast.LENGTH_LONG).show();
                } else{
                    Log.d("rating","Already rated");

                    final AlertDialog.Builder popUpBox = new AlertDialog.Builder(TouristPlacePage.this);
                    final AlertDialog alert = popUpBox.create();

                    //Setting configuration for the pop up box
                    popUpBox.setTitle("Alert");
                    popUpBox.setMessage("Are you sure you want to update your ratings?");
                    popUpBox.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Login.connection.getUserDao().updateRating(username,touristPlace.getId(),Double.valueOf(ratingBarByUser.getRating()));
                            Toast.makeText(TouristPlacePage.this,"Ratings updated",Toast.LENGTH_LONG).show();
                        }
                    });

                    popUpBox.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alert.cancel();
                        }
                    });

                    popUpBox.show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if(itemId == android.R.id.home){
            finish();
        }
        return true;
    }
}
