package com.example.tokyotour.Tourist;

import android.content.Context;
import android.media.Image;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.R;

import java.util.List;

public class TouristPlaceCustomAdapter extends ArrayAdapter<TouristPlace> {

    Context context;
    int resource;
    List<TouristPlace> touristPlace;

    public TouristPlaceCustomAdapter(@NonNull Context context, int resource, @NonNull List<TouristPlace> objects) {
        super(context, resource, objects);

        this.context = context;
        this.resource = resource;
        this.touristPlace = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(this.context);
        convertView = inflater.inflate(this.resource,parent,false);

        ImageView photo;
        TextView title,summary,price;

        title = convertView.findViewById(R.id.list_item_name);
        summary = convertView.findViewById(R.id.list_item_summary);
        photo = convertView.findViewById(R.id.list_item_image);
        price = convertView.findViewById(R.id.list_item_price);

        title.setText(touristPlace.get(position).getName());
        summary.setText(touristPlace.get(position).getDescription());
        if(touristPlace.get(position).getPrice() == 0){
            price.setText("FREE");
        } else{
            price.setText("$"+touristPlace.get(position).getPrice());
        }

        Uri uri = Uri.parse(touristPlace.get(position).getImage());
        photo.setImageURI(uri);

        return convertView;
    }
}
