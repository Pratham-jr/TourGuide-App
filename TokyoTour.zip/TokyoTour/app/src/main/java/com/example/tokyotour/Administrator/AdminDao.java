package com.example.tokyotour.Administrator;

import androidx.room.Dao;
import androidx.room.Insert;

import com.example.tokyotour.ModelClasses.TouristPlace;

@Dao
public interface AdminDao {

    @Insert
    void addTouristPlace(TouristPlace touristPlace);
}
