package com.example.tokyotour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tokyotour.Administrator.AdminPanel;
import com.example.tokyotour.ModelClasses.User;

import java.util.ArrayList;
import java.util.List;

public class Login extends AppCompatActivity {

    EditText username,password;
    TextView signup;
    Button login;
    public static MyDatabase connection;
    List<User> users;
    boolean flag = false;
    AlertDialog.Builder popUpBox;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferenceEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.login_username_ET);
        password = findViewById(R.id.login_password_ET);
        signup = findViewById(R.id.login_signup_TV);
        login = findViewById(R.id.login_signin_Btn);

        connection = Room.databaseBuilder(getApplicationContext(),MyDatabase.class,"touristapp").allowMainThreadQueries().build();

        createAdmin();

        sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
        Boolean isAdmin = sharedPreferences.getBoolean("isAdmin", false);
        String usernameStr = sharedPreferences.getString("username","");

        //User has already logged in
        if(!usernameStr.equals("")){
            if(!isAdmin){
                Intent intent = new Intent(Login.this,MainActivity.class);
                startActivity(intent);
                finish();
            } else{
                Intent intent = new Intent(Login.this,AdminPanel.class);
                startActivity(intent);
                finish();
            }
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                users = connection.getUserDao().getAllUsers();

                if(validate()){
                    for(int i=0;i<users.size();i++){
                        //User exists
                        if(users.get(i).getUsername().equals(username.getText().toString()) && users.get(i).getPassword().equals(password.getText().toString())){
                            flag = true;

                            preferenceEditor = sharedPreferences.edit();
                            preferenceEditor.putString("username", username.getText().toString());
                            preferenceEditor.putString("password", password.getText().toString());

                            //If admin
                            if(users.get(i).getIsAdmin()){
                                preferenceEditor.putBoolean("isAdmin",true);
                                preferenceEditor.apply();
                                Intent intent = new Intent(Login.this, AdminPanel.class);
                                startActivity(intent);
                                finish();
                            } else{
                                //If not an admin
                                preferenceEditor.putBoolean("isAdmin",false);
                                preferenceEditor.apply();
                                Intent intent = new Intent(Login.this,MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }

                    if(!flag){
                        popUpBox = new AlertDialog.Builder(Login.this);

                        //Setting configuration for the pop up box
                        popUpBox.setTitle("Error!");
                        popUpBox.setMessage("User does not exists!");
                        popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                username.getText().clear();
                                password.getText().clear();
                                username.requestFocus();
                            }
                        });
                        popUpBox.show();
                    }
                } else{ //Not all fields are filled
                    popUpBox = new AlertDialog.Builder(Login.this);

                    //Setting configuration for the pop up box
                    popUpBox.setTitle("Error!");
                    popUpBox.setMessage("All fields are required!");
                    popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            username.getText().clear();
                            password.getText().clear();
                            username.requestFocus();
                        }
                    });
                    popUpBox.show();
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup.setBackgroundColor(getResources().getColor(R.color.background));
                Intent intent = new Intent(Login.this,Signup.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void createAdmin() {
        User user = new User("admin","admin",true);
        connection.getUserDao().addUser(user);
    }

    private boolean validate() {
        if(!username.getText().toString().equals("") && !password.getText().toString().equals("")){
            return true;
        }

        return false;
    }
}
