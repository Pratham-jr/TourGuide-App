package com.example.tokyotour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tokyotour.ModelClasses.User;

import java.util.List;

public class Signup extends AppCompatActivity {

    EditText username,password;
    TextView login;
    Button signupBtn;
    List<User> users;
    boolean flag = false;
    AlertDialog.Builder popUpBox;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferenceEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        username = findViewById(R.id.signup_username_ET);
        password = findViewById(R.id.signup_password_ET);
        login = findViewById(R.id.signup_login_TV);
        signupBtn = findViewById(R.id.signup_signup_Btn);

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                users = Login.connection.getUserDao().getAllUsers();

                if(validate()){
                    for(int i=0;i<users.size();i++){
                        //User exists
                        if(users.get(i).getUsername().equals(username.getText().toString())){
                            flag = true;
                            break;
                        }
                    }

                    if(flag){
                        popUpBox = new AlertDialog.Builder(Signup.this);

                        //Setting configuration for the pop up box
                        popUpBox.setTitle("Error!");
                        popUpBox.setMessage("User already exists!");
                        popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                username.getText().clear();
                                password.getText().clear();
                                username.requestFocus();
                            }
                        });
                        popUpBox.show();
                    } else{
                        User user = new User(username.getText().toString(),password.getText().toString(),false);
                        Login.connection.getUserDao().addUser(user);

                        sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);

                        preferenceEditor = sharedPreferences.edit();
                        preferenceEditor.putString("username", username.getText().toString());
                        preferenceEditor.putString("password", password.getText().toString());
                        preferenceEditor.apply();

                        Toast.makeText(Signup.this,"User created",Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(Signup.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } else{ //Not all fields are filled
                    popUpBox = new AlertDialog.Builder(Signup.this);

                    //Setting configuration for the pop up box
                    popUpBox.setTitle("Error!");
                    popUpBox.setMessage("All fields are required!");
                    popUpBox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            username.getText().clear();
                            password.getText().clear();
                            username.requestFocus();
                        }
                    });
                    popUpBox.show();
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login.setBackgroundColor(getResources().getColor(R.color.background));
                Intent intent = new Intent(Signup.this, Login.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private boolean validate() {
        if(!username.getText().toString().equals("") && !password.getText().toString().equals("")){
            return true;
        }

        return false;
    }
}
