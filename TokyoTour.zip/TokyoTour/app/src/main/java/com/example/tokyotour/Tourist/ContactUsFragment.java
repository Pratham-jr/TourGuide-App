package com.example.tokyotour.Tourist;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.tokyotour.R;


public class ContactUsFragment extends Fragment {

    ImageButton call,sms,email;
    TextView getDirection;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact_us, container, false);

        call = view.findViewById(R.id.call_us);
        sms = view.findViewById(R.id.message_us);
        email = view.findViewById(R.id.email_us);
        getDirection = view.findViewById(R.id.contact_us_get_direction);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callUs();
            }
        });

        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                smsUs();
            }
        });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mailUs();
            }
        });

        getDirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDirection.setBackgroundColor(getContext().getResources().getColor(R.color.background));
                Uri gmmIntentUri = Uri.parse("geo:43.676022,-79.411049?q=college");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if (mapIntent.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivity(mapIntent);
                }
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        getDirection.setBackgroundColor(getContext().getResources().getColor(R.color.colorPrimary));
    }

    private void smsUs(){
        String number = "5556";
        String formatPhoneNumber = "smsto:" + number;

        String msg = "Hello. ";

        //You need to send phone number and message to the intent
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse(formatPhoneNumber));
        intent.putExtra("sms_body",msg);

        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
        else {
            Log.d("ContactUs", "ERROR: Cannot find app that matches ACTION_SENDTO intent");
        }
    }

    private void callUs() {

        String formatPhoneNumber = "tel:5556";

        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse(formatPhoneNumber));

        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
        else {
            Log.d("ContactUs", "ERROR: Cannot find app that matches ACTION_CALL intent");
        }
    }

    private void mailUs(){
        Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);

        /* Fill it with Data */
        emailIntent.setType("plain/text");
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"dhruvam.sp2@gmail.com"});
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "CUSTOMER CARE");
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Hello. ");

        /* Send it off to the Activity-Chooser */
        getActivity().startActivity(Intent.createChooser(emailIntent, "Send mail..."));
    }
}
