package com.example.tokyotour.Tourist;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.tokyotour.R;

public class OverallSchedule extends Fragment {

    WebView webView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_overall_schedule, container, false);

        webView = view.findViewById(R.id.overall_schedule_webview);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://tokyo2020.org/en/games/schedule/olympic/");
        webView.setWebViewClient(new WebViewClient());

        return view;
    }
}
