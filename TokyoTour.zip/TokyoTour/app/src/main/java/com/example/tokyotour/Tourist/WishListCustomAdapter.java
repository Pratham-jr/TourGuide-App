package com.example.tokyotour.Tourist;

import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.example.tokyotour.Login;
import com.example.tokyotour.MainActivity;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.ModelClasses.WishList;
import com.example.tokyotour.R;

import java.util.List;

public class WishListCustomAdapter extends ArrayAdapter<TouristPlace> {

    Context context;
    int resource;
    List<TouristPlace> touristPlaceList;

    public WishListCustomAdapter(@NonNull Context context, int resource, @NonNull List<TouristPlace> objects) {
        super(context, resource, objects);

        this.context = context;
        this.resource = resource;
        this.touristPlaceList = objects;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(this.context);
        convertView = inflater.inflate(this.resource,parent,false);

        TextView title,price,description;
        ImageView photo;

        title = convertView.findViewById(R.id.list_item_name);
        price = convertView.findViewById(R.id.list_item_price);
        description = convertView.findViewById(R.id.list_item_summary);
        photo = convertView.findViewById(R.id.list_item_image);

        title.setText(touristPlaceList.get(position).getName());
        description.setText(touristPlaceList.get(position).getDescription());
        if(touristPlaceList.get(position).getPrice() == 0){
            price.setText("FREE");
        } else{
            price.setText("$"+touristPlaceList.get(position).getPrice());
        }

        Uri uri = Uri.parse(touristPlaceList.get(position).getImage());
        photo.setImageURI(uri);

        return convertView;
    }
}
