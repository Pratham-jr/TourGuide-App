package com.example.tokyotour.Tourist;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.DialogFragment;

import com.example.tokyotour.MainActivity;
import com.example.tokyotour.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

    WebView webView;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferenceEditor;

    public DatePickerFragment(WebView webview){
        this.webView = webview;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return new DatePickerDialog(getActivity(),this,year,month,day);
    }

    @Override
    public void onDateSet(DatePicker view, final int year, int month, int dayOfMonth) {

        final String dayStr;
        final String monthStr;

        if(month < 10){
            monthStr = "0"+(month+1);
        } else{
            monthStr = String.valueOf((month+1));
        }

        if(dayOfMonth < 10){
            dayStr = "0"+dayOfMonth;
        } else{
            dayStr = String.valueOf(dayOfMonth);
        }

        //Getting previous day date in string format
        String input = year+monthStr+dayStr;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Date myDate = null;
        try {
            myDate = dateFormat.parse(input);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(myDate);
        cal1.add(Calendar.DAY_OF_YEAR, -1);
        final SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        Date d = null;
        try {
            d = sdf.parse(String.valueOf(cal1.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        sdf.applyPattern("yyyyMMdd");
        Log.d("date","Previous: "+sdf.format(d));
        final String date = sdf.format(d);

        Log.d("date","year: "+year);
        Log.d("date","month: "+monthStr);
        Log.d("date","day: "+dayStr);

        String url = "https://tokyo2020.org/en/games/schedule/olympic/"+year+monthStr+dayStr+".html";
        webView.loadUrl(url);

        //Ask if user wants to set notification for that day
        AlertDialog.Builder popUpBox = new AlertDialog.Builder(getContext());

        sharedPreferences = getContext().getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
        preferenceEditor = sharedPreferences.edit();

        //Setting configuration for the pop up box
        popUpBox.setTitle("Reminder");
        popUpBox.setMessage("Do you wish to be notified for this event a day before?");
        popUpBox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //String date = year+monthStr+dayStr;
                String notification = "";
                notification = sharedPreferences.getString("notification","");
                if(!notification.equals("")){
                    preferenceEditor.remove("notification");
                    preferenceEditor.apply();
                    Log.d("noti","removed");
                } else{
                    Log.d("noti","new");
                }
                preferenceEditor.putString("notification",date);
                preferenceEditor.apply();
                Log.d("noti","Stored: "+sharedPreferences.getString("notification",""));
                Log.d("noti","Date in picker: "+date);
            }
        });

        popUpBox.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        popUpBox.show();
    }
}
