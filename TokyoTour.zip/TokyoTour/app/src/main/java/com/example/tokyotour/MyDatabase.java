package com.example.tokyotour;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.tokyotour.Administrator.AdminDao;
import com.example.tokyotour.ModelClasses.Rating;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.ModelClasses.User;
import com.example.tokyotour.ModelClasses.WishList;

@Database(entities = {User.class, TouristPlace.class, WishList.class, Rating.class},version = 4)
public abstract class MyDatabase extends RoomDatabase {

    public abstract UserDao getUserDao();

    public abstract AdminDao getAdminDao();
}
