package com.example.tokyotour;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import com.example.tokyotour.Administrator.AdminPanel;
import com.example.tokyotour.Tourist.ContactUsFragment;
import com.example.tokyotour.Tourist.DaySchedule;
import com.example.tokyotour.Tourist.OverallSchedule;
import com.example.tokyotour.Tourist.TouristPlace;
import com.example.tokyotour.Tourist.WishListFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferenceEditor;
    public static final String CHANNEL_ID = "Reminder";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
        preferenceEditor = sharedPreferences.edit();
        String username = sharedPreferences.getString("username", "");

        View navHeader = navigationView.getHeaderView(0);
        TextView usernameTV = navHeader.findViewById(R.id.nav_username);
        usernameTV.setText("Hello, "+username);

        createNotificationChannel();

        String notificationDate = "";
        notificationDate = sharedPreferences.getString("notification","");

        if(!notificationDate.equals("")){
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            String monthStr,dayStr;

            if(day < 10){
                dayStr = "0"+(day);
            } else{
                dayStr = String.valueOf(day);
            }

            if(month < 10){
                monthStr = "0"+(month+1);
            } else{
                monthStr = String.valueOf((month+1));
            }

            //String notificationDate = notification.substring(0,6)+notiDayStr;
            String currentDate = year+monthStr+dayStr;

            if(notificationDate.equals(currentDate)){
                Log.d("noti","MATCHED");
                showNotification();
            }

            //showNotificationPressed();
        }

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new TouristPlace()).commit();
    }

    public void showNotification() {

        // Code to handle what should happen when you click on the notification
        // Create an explicit intent for an Activity in your app
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, "Reminder")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("EVENT REMINDER")
                        .setContentText("Event is going to be held tomorrow.")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        // notificationId is a unique int for each notification that you must define
        int notificationId = 2222;
        notificationManager.notify(notificationId, builder.build());
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            //@TODO: update this
            CharSequence name = "Event reminder";
            String description = "channel for sending notifications for events";

            //@TODO: all nonsensese default code
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        switch (itemId){

            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new TouristPlace()).commit();
                break;
            case R.id.nav_wishlist:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new WishListFragment()).commit();
                break;
            case R.id.contact_us:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ContactUsFragment()).commit();
                break;
            case R.id.nav_logout:
                sharedPreferences = getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
                preferenceEditor = sharedPreferences.edit();

                preferenceEditor.remove("username");
                preferenceEditor.remove("password");
                preferenceEditor.remove("isAdmin");
                preferenceEditor.apply();

                Intent intent = new Intent(MainActivity.this,Login.class);
                startActivity(intent);
                finish();
                break;
            case R.id.nav_olympics_overall_schedule:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new OverallSchedule()).commit();
                break;
            case R.id.nav_olympics_day_schedule:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new DaySchedule()).commit();
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
