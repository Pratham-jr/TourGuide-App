package com.example.tokyotour.Tourist;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.example.tokyotour.R;

import java.util.Calendar;

public class DaySchedule extends Fragment {

    TextView daySelect;
    WebView webView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_day_schedule, container, false);

        daySelect = view.findViewById(R.id.day_schedule_select_date);
        webView = view.findViewById(R.id.day_schedule_webview);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://tokyo2020.org/en/games/schedule/olympic/");
        webView.setWebViewClient(new WebViewClient());

        daySelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datePickerfragment = new DatePickerFragment(webView);
                datePickerfragment.show(getActivity().getSupportFragmentManager(),"datePicker");
            }
        });

        return view;
    }
}
