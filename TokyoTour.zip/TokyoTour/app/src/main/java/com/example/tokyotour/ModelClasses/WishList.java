package com.example.tokyotour.ModelClasses;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "wishlist")
public class WishList {

    @PrimaryKey(autoGenerate = true)
    private int wishListId;
    private String username;
    private int id;

    private boolean isAvailable;

    public WishList(String username, int id,boolean isAvailable) {
        this.username = username;
        this.id = id;
        this.isAvailable = isAvailable;
    }

    public int getWishListId() {
        return wishListId;
    }

    public void setWishListId(int wishListId) {
        this.wishListId = wishListId;
    }

    public String getUsername() {
        return username;
    }

    public int getId() {
        return id;
    }

    public boolean isAvailable() {
        return isAvailable;
    }
}
