package com.example.tokyotour.Tourist;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.tokyotour.Login;
import com.example.tokyotour.ModelClasses.TouristPlace;
import com.example.tokyotour.ModelClasses.WishList;
import com.example.tokyotour.R;

import org.w3c.dom.Text;

import java.util.List;


public class WishListFragment extends Fragment {

    ListView listView;
    TextView emptyTitle;
    List<TouristPlace> touristPlaceList;
    SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wish_list, container, false);

        listView = view.findViewById(R.id.wishlist_list_view);
        emptyTitle = view.findViewById(R.id.wishlist_empty);

        sharedPreferences = getActivity().getSharedPreferences("tokyotour", Context.MODE_PRIVATE);
        final String username = sharedPreferences.getString("username", "");

        touristPlaceList = Login.connection.getUserDao().getPlaceForWishList(username);

        if(touristPlaceList.size() == 0){
            emptyTitle.setVisibility(View.VISIBLE);
        } else{
            emptyTitle.setVisibility(View.GONE);
        }

        final WishListCustomAdapter adapter = new WishListCustomAdapter(getContext(),R.layout.wishlist_list_item,touristPlaceList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView delete = view.findViewById(R.id.list_item_delete);
                final int pos = position;
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final AlertDialog.Builder popUpBox = new AlertDialog.Builder(getContext());
                        final AlertDialog alert = popUpBox.create();

                        //Setting configuration for the pop up box
                        popUpBox.setTitle("Alert");
                        popUpBox.setMessage("Are you sure you want to remove from wishlist?");
                        popUpBox.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Login.connection.getUserDao().removePlacefromWishlist(touristPlaceList.get(pos).getId());
                                touristPlaceList.clear();
                                touristPlaceList.addAll(Login.connection.getUserDao().getPlaceForWishList(username));
                                adapter.notifyDataSetChanged();

                                if(touristPlaceList.size() == 0){
                                    emptyTitle.setVisibility(View.VISIBLE);
                                } else{
                                    emptyTitle.setVisibility(View.GONE);
                                }

                                alert.cancel();
                            }
                        });
                        popUpBox.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                alert.cancel();
                            }
                        });

                        popUpBox.show();
                    }
                });
            }
        });


        return view;
    }
}
