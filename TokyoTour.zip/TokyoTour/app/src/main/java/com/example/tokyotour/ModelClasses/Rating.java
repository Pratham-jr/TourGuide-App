package com.example.tokyotour.ModelClasses;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "rating")
public class Rating {

    @PrimaryKey(autoGenerate = true)
    private int ratingId;
    private String username;
    private int placeId;
    private double ratingNum;

    public Rating(String username, int placeId, double ratingNum) {
        this.username = username;
        this.placeId = placeId;
        this.ratingNum = ratingNum;
    }

    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    public int getRatingId() {
        return ratingId;
    }

    public String getUsername() {
        return username;
    }

    public int getPlaceId() {
        return placeId;
    }

    public double getRatingNum() {
        return ratingNum;
    }
}
